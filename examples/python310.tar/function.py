def handler(params, context):
    return "Hello, Serverledge!\nParams: {}".format(params)
